
package controller;

import javax.swing.JOptionPane;
import model.Cad;

public class UsaCad {
    Cad primeiroNo;
    Cad ultimoNO;
    int cont;
    
    UsaCad(){
        primeiroNo = null;
        ultimoNO = null;
        cont = 0;
    }
    void addCad(Object dado){
        Cad newCad = new Cad();
        newCad.dado = dado;
        newCad.liga = null;
        cont++;
        if(primeiroNo == null){
            primeiroNo = newCad;
            ultimoNO   = newCad;
        }
        else{
            ultimoNO.liga = newCad;
        }
        ultimoNO = newCad;
    }
    void plotar(){
        Cad temp = primeiroNo;
        while(temp != null){
            System.out.println(temp.dado);
            temp = temp.liga;
        }
        
    }
    void destrutor(){
        Cad temp = primeiroNo;
        Cad aux;
        while(temp != null){
            aux = temp;
            aux = null;
            temp = temp.liga;
        }
        JOptionPane.showMessageDialog(null,"Estrutura destruida...!");
    }
    public static void main(String[] args) {
        UsaCad u1 = new UsaCad();
        
        String menu = "***|PROJETO CAD|***\n 1-Inserir\n 2-Listar\n 3-Destruir\n 4-Sair\nItem:";
        while(true){
            String item = JOptionPane.showInputDialog(null, menu);
            switch(item){
                case "1":
                    String nome = JOptionPane.showInputDialog(null,"Insira um nome: ");
                    u1.addCad(nome);
                    break;
                case "2":      
                    u1.plotar();
                    break;
                case "3":
                    u1.destrutor();
                    break;
                case "4":              
                    System.exit(0);
                    break;
                case "5":
                    break;
                }                 
            }         
    }
}