
package model;

public class Cad {
    public Object dado;
    public Cad liga;
}
